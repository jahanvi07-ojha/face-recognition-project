import cv2
import numpy as np
import os
from PIL import Image
from datetime import datetime
import csv
import smtplib
import ssl
from email.message import EmailMessage

def send_email_alert(image_path):
    EMAIL_ADDRESS = "jahanviojha87@gmail.com"
    EMAIL_PASSWORD = "uodl qmch hkzi ptjb"  # Use app password if 2FA is enabled

    msg = EmailMessage()
    msg['Subject'] = 'Unknown Face Detected!'
    msg['From'] = EMAIL_ADDRESS
    msg['To'] = "ojhajahanvi067@gmail.com"
    msg.set_content('An unknown face was detected. See the attached image.')

    # Attach image
    with open(image_path, 'rb') as img:
        img_data = img.read()
        msg.add_attachment(img_data, maintype='image', subtype='jpeg', filename=os.path.basename(image_path))

    # Send email
    context = ssl.create_default_context()
    with smtplib.SMTP_SSL('smtp.gmail.com', 465, context=context) as smtp:
        smtp.login(EMAIL_ADDRESS, EMAIL_PASSWORD)
        smtp.send_message(msg)

    print(f"Email sent with attachment: {image_path}")


def  generate_dataset(user_id = 1, sample_count=200):
    face_classifier = cv2.CascadeClassifier("haarcascade_frontalface_alt2.xml")
    def face_cropped(img):
     gray=cv2.cvtColor(img,cv2.COLOR_BGR2GRAY)
     faces=face_classifier.detectMultiScale(gray ,1.3,5)
     if len(faces) == 0:
        return None
     for (x,y,w,h) in faces:
           return img[y:y+h,x:x+w]
    cap = cv2.VideoCapture(0)
    img_id =0
    os.makedirs("data",exist_ok=True)
    while True:
      ret,frame  = cap.read()
      if not ret:
         continue
      face = face_cropped(frame)
      if face is not None:
       img_id+=1
       face =cv2.resize(face,(200,200))
       gray_face = cv2.cvtColor(face,cv2.COLOR_BGR2GRAY)
       file_path = f"data/user.{user_id}.{img_id}.jpg"
       cv2.imwrite(file_path,gray_face)
       cv2.putText(gray_face,str(img_id),(10,30),cv2.FONT_HERSHEY_SIMPLEX,1,(255,255,255),2)
       cv2.imshow("Capturing Faces",gray_face)
      if cv2.waitKey(1)== 13 or img_id>=sample_count:
       break
    cap.release()
    cv2.destroyAllWindows()
    print(f"sample collection for user {user_id}completed")  
#if __name__ =="__main__":
   #generate_dataset()
def train_classifier(data_dir ="data"):
   if not os.path.exists(data_dir):
     print("Data directory not found.")
     return
   path =[os.path.join(data_dir,f)for f in os.listdir(data_dir)]
   faces, ids =[],[]
   for image in path:
      img = Image.open(image).convert('L')
      image_np = np.array(img,'uint8')
      id = int(os.path.split(image)[1].split(".")[1])
      faces.append(image_np)
      ids.append(id)
   if not faces:
      print("No images found for training")
      return
   ids = np.array(ids)
   clf = cv2.face.LBPHFaceRecognizer_create()
   clf.train(faces,ids)
   clf.write("classifier.xml")
   print("training completed and model saved as classifier.xml")
#if __name__ =="__main__":
   #train_classifier()

def recognize_face():
    def log_recognition(user_id):
        with open("log.csv", "a", newline="") as file:
            writer = csv.writer(file)
            now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            writer.writerow([user_id, now])
            print(f"Logged: User {user_id} at {now}")

    def save_unknown_face(face_img):
        os.makedirs("unknown_faces", exist_ok=True)
        now = datetime.now().strftime("%Y%m%d_%H%M%S")
        filename = f"unknown_faces/unknown_{now}.jpg"
        cv2.imwrite(filename, face_img)
        print(f"Unknown face saved: {filename}")
        send_email_alert(filename)

    def preprocess_face(face_img):
        # Resize and equalize histogram for better lighting consistency
        face_resized = cv2.resize(face_img, (200, 200))
        face_eq = cv2.equalizeHist(face_resized)
        return face_eq

    # Load Haar Cascade
    face_cascade = cv2.CascadeClassifier(cv2.data.haarcascades + "haarcascade_frontalface_alt2.xml")

    # Load trained LBPH model
    clf = cv2.face.LBPHFaceRecognizer_create()
    clf.read("classifier.xml")

    cap = cv2.VideoCapture(0)

    print("Starting Face Recognition... Press Enter to quit.")

    while True:
        ret, frame = cap.read()
        if not ret:
            print("Failed to capture video frame.")
            break

        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        faces = face_cascade.detectMultiScale(gray, scaleFactor=1.2, minNeighbors=5)

        for (x, y, w, h) in faces:
            roi_gray = gray[y:y+h, x:x+w]
            processed_face = preprocess_face(roi_gray)

            id, confidence = clf.predict(processed_face)

            if confidence < 50:  # Adjust threshold as needed (lower = better match)
                label = f"User {id} ({confidence:.1f})"
                log_recognition(id)
            else:
                label = "Unknown"
                save_unknown_face(frame[y:y+h, x:x+w])

            cv2.rectangle(frame, (x, y), (x+w, y+h), (0, 255, 0), 2)
            cv2.putText(frame, label, (x, y-10), cv2.FONT_HERSHEY_SIMPLEX, 0.8, (255, 255, 255), 2)

        cv2.imshow("Face Recognition", frame)
        if cv2.waitKey(1) == 13:  # Press Enter to exit
            break

    cap.release()
    cv2.destroyAllWindows()
    print("Recognition stopped.")

recognize_face()

